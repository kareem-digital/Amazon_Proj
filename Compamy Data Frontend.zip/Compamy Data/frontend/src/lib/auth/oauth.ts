import {
  UserManager,
  WebStorageStateStore,
  type User,
  type UserManagerSettings,
} from "oidc-client-ts";

import type { OAuthConfig } from "@/lib/config";

const EXPIRY_MARGIN_SECONDS = 30;
const STANDALONE_ROOT = "/agent/";

export type AccessTokenProvider = () => Promise<string>;
export type InteractiveSignInMode = "popup" | "redirect";

interface OidcUserManager {
  getUser(): Promise<User | null>;
  removeUser(): Promise<void>;
  signinPopup(args?: { resource?: string | string[] }): Promise<User>;
  signinPopupCallback(url?: string): Promise<void>;
  signinSilent(args?: { resource?: string | string[] }): Promise<User | null>;
  signinRedirect(args?: {
    resource?: string | string[];
    state?: unknown;
  }): Promise<void>;
  signinRedirectCallback(url?: string): Promise<User>;
}

export function userManagerSettings(config: OAuthConfig): UserManagerSettings {
  return {
    authority: config.authority,
    client_id: config.clientId,
    redirect_uri: config.redirectUri,
    popup_redirect_uri: config.popupRedirectUri,
    response_type: "code",
    scope: config.scope,
    resource: config.resource,
    disablePKCE: false,
    loadUserInfo: false,
    automaticSilentRenew: false,
    monitorSession: false,
    stateStore: new WebStorageStateStore({ store: window.sessionStorage }),
    userStore: new WebStorageStateStore({ store: window.sessionStorage }),
  };
}

export function createOidcUserManager(config: OAuthConfig): UserManager {
  return new UserManager(userManagerSettings(config));
}

/**
 * Supplies a short-lived access token to the HTTP layer.
 *
 * ID tokens never leave this module. An existing refresh token is used before
 * opening a popup, and concurrent API calls share one renewal/sign-in attempt.
 */
export class OAuthAccessTokenProvider {
  private pending: Promise<string> | null = null;

  constructor(
    private readonly config: OAuthConfig,
    private readonly manager: OidcUserManager = createOidcUserManager(config),
    private readonly interactiveSignIn: InteractiveSignInMode = "popup",
  ) {}

  getAccessToken = (): Promise<string> => {
    if (!this.pending) {
      this.pending = this.resolveToken().finally(() => {
        this.pending = null;
      });
    }
    return this.pending;
  };

  private async resolveToken(): Promise<string> {
    const current = await this.manager.getUser();
    if (
      current?.access_token &&
      current.expires_in !== undefined &&
      current.expires_in > EXPIRY_MARGIN_SECONDS
    ) {
      return current.access_token;
    }

    if (current?.refresh_token) {
      try {
        const refreshed = await this.manager.signinSilent({
          resource: this.config.resource,
        });
        if (refreshed?.access_token) return refreshed.access_token;
      } catch {
        // A reused/revoked refresh token requires a new authorization code.
        await this.manager.removeUser();
      }
    }

    if (this.interactiveSignIn === "redirect") {
      await startOAuthRedirect(this.config, this.manager);
      // `signinRedirect` assigns the browser location. Keep the interrupted API
      // request pending during that brief hand-off so chat does not render a
      // misleading transport error before the page unloads.
      return await new Promise<string>(() => undefined);
    }

    const signedIn = await this.manager.signinPopup({ resource: this.config.resource });
    if (!signedIn.access_token) {
      throw new Error("VOW did not issue an access token for VOW Agent.");
    }
    return signedIn.access_token;
  }
}

export async function startOAuthRedirect(
  config: OAuthConfig,
  manager: OidcUserManager = createOidcUserManager(config),
  returnTo = STANDALONE_ROOT,
): Promise<void> {
  await manager.signinRedirect({
    resource: config.resource,
    state: { returnTo: safeStandaloneReturnTo(returnTo) },
  });
}

export async function completeOAuthRedirect(
  config: OAuthConfig,
  manager: OidcUserManager = createOidcUserManager(config),
): Promise<string> {
  const user = await manager.signinRedirectCallback(window.location.href);
  const state = user.state;
  if (state && typeof state === "object" && "returnTo" in state) {
    return safeStandaloneReturnTo(
      (state as { returnTo?: unknown }).returnTo,
    );
  }
  return STANDALONE_ROOT;
}

function safeStandaloneReturnTo(value: unknown): string {
  if (
    typeof value !== "string" ||
    !value.startsWith(STANDALONE_ROOT) ||
    value.startsWith("//")
  ) {
    return STANDALONE_ROOT;
  }
  return value;
}

export async function completeOAuthPopup(
  config: OAuthConfig,
  manager: OidcUserManager = createOidcUserManager(config),
): Promise<void> {
  await manager.signinPopupCallback(window.location.href);
}
