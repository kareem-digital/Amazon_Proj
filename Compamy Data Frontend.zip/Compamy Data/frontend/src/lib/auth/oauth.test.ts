import { User } from "oidc-client-ts";
import { describe, expect, it, vi } from "vitest";

import {
  completeOAuthRedirect,
  completeOAuthPopup,
  OAuthAccessTokenProvider,
  startOAuthRedirect,
  userManagerSettings,
} from "@/lib/auth/oauth";
import type { OAuthConfig } from "@/lib/config";

const oauth: OAuthConfig = {
  authority: "https://vow.example.com/api/identity/oauth2",
  clientId: "vow-agent-mfe",
  resource: "https://vow.example.com/agent-api",
  redirectUri: "https://vow.example.com/agent/oauth/login-callback",
  popupRedirectUri: "https://vow.example.com/agent/oauth/callback",
  scope: "openid read",
};

function user(
  accessToken: string,
  options: { expiresIn?: number; refreshToken?: string } = {},
): User {
  return new User({
    access_token: accessToken,
    refresh_token: options.refreshToken,
    token_type: "Bearer",
    scope: oauth.scope,
    profile: {
      iss: oauth.authority,
      sub: "user-1",
      aud: oauth.clientId,
      exp: Math.floor(Date.now() / 1000) + (options.expiresIn ?? 600),
      iat: Math.floor(Date.now() / 1000),
    },
    expires_at: Math.floor(Date.now() / 1000) + (options.expiresIn ?? 600),
  });
}

function manager(current: User | null) {
  return {
    getUser: vi.fn().mockResolvedValue(current),
    removeUser: vi.fn().mockResolvedValue(undefined),
    signinPopup: vi.fn().mockResolvedValue(user("popup-token")),
    signinPopupCallback: vi.fn().mockResolvedValue(undefined),
    signinSilent: vi.fn().mockResolvedValue(user("refreshed-token")),
    signinRedirect: vi.fn().mockResolvedValue(undefined),
    signinRedirectCallback: vi.fn().mockResolvedValue(user("redirect-token")),
  };
}

describe("OAuthAccessTokenProvider", () => {
  it("configures code flow, PKCE, OIDC scope and resource indication", () => {
    const settings = userManagerSettings(oauth);

    expect(settings).toMatchObject({
      authority: oauth.authority,
      client_id: "vow-agent-mfe",
      redirect_uri: oauth.redirectUri,
      popup_redirect_uri: oauth.popupRedirectUri,
      response_type: "code",
      scope: "openid read",
      resource: oauth.resource,
      disablePKCE: false,
      loadUserInfo: false,
    });
  });

  it("reuses a valid access token without opening an authorization window", async () => {
    const oidc = manager(user("current-token"));
    const provider = new OAuthAccessTokenProvider(oauth, oidc);

    await expect(provider.getAccessToken()).resolves.toBe("current-token");
    expect(oidc.signinSilent).not.toHaveBeenCalled();
    expect(oidc.signinPopup).not.toHaveBeenCalled();
  });

  it("refreshes an expiring token and repeats the resource parameter", async () => {
    const oidc = manager(
      user("expiring-token", { expiresIn: 10, refreshToken: "refresh-token" }),
    );
    const provider = new OAuthAccessTokenProvider(oauth, oidc);

    await expect(provider.getAccessToken()).resolves.toBe("refreshed-token");
    expect(oidc.signinSilent).toHaveBeenCalledWith({
      resource: oauth.resource,
    });
    expect(oidc.signinPopup).not.toHaveBeenCalled();
  });

  it("falls back to the session-backed authorization popup", async () => {
    const oidc = manager(null);
    const provider = new OAuthAccessTokenProvider(oauth, oidc);

    await expect(provider.getAccessToken()).resolves.toBe("popup-token");
    expect(oidc.signinPopup).toHaveBeenCalledWith({ resource: oauth.resource });
  });

  it("removes stale state and reauthorizes after refresh rejection", async () => {
    const oidc = manager(
      user("expired", { expiresIn: -10, refreshToken: "rejected-refresh" }),
    );
    oidc.signinSilent.mockRejectedValue(new Error("invalid_grant"));
    const provider = new OAuthAccessTokenProvider(oauth, oidc);

    await expect(provider.getAccessToken()).resolves.toBe("popup-token");
    expect(oidc.removeUser).toHaveBeenCalledOnce();
    expect(oidc.signinPopup).toHaveBeenCalledOnce();
  });

  it("coalesces concurrent calls into one sign-in", async () => {
    const oidc = manager(null);
    const provider = new OAuthAccessTokenProvider(oauth, oidc);

    await expect(
      Promise.all([provider.getAccessToken(), provider.getAccessToken()]),
    ).resolves.toEqual(["popup-token", "popup-token"]);
    expect(oidc.signinPopup).toHaveBeenCalledOnce();
  });

  it("uses a full-page redirect when standalone reauthentication is required", async () => {
    const oidc = manager(null);
    const provider = new OAuthAccessTokenProvider(oauth, oidc, "redirect");

    void provider.getAccessToken();
    await vi.waitFor(() =>
      expect(oidc.signinRedirect).toHaveBeenCalledWith({
        resource: oauth.resource,
        state: { returnTo: "/agent/" },
      }),
    );
    expect(oidc.signinPopup).not.toHaveBeenCalled();
  });
});

it("starts standalone authorization with a safe return location", async () => {
  const oidc = manager(null);

  await startOAuthRedirect(oauth, oidc, "/agent/conversation?session=123");

  expect(oidc.signinRedirect).toHaveBeenCalledWith({
    resource: oauth.resource,
    state: { returnTo: "/agent/conversation?session=123" },
  });
});

it("falls back to the standalone root for an unsafe return location", async () => {
  const oidc = manager(null);

  await startOAuthRedirect(oauth, oidc, "https://attacker.example.com");

  expect(oidc.signinRedirect).toHaveBeenCalledWith({
    resource: oauth.resource,
    state: { returnTo: "/agent/" },
  });
});

it("completes a standalone redirect and restores its safe location", async () => {
  const oidc = manager(null);
  oidc.signinRedirectCallback.mockResolvedValue(
    Object.assign(user("redirect-token"), {
      state: { returnTo: "/agent/conversation?session=123" },
    }),
  );

  await expect(completeOAuthRedirect(oauth, oidc)).resolves.toBe(
    "/agent/conversation?session=123",
  );
  expect(oidc.signinRedirectCallback).toHaveBeenCalledWith(window.location.href);
});

it("notifies the opener when the popup reaches the callback route", async () => {
  const oidc = manager(null);

  await completeOAuthPopup(oauth, oidc);

  expect(oidc.signinPopupCallback).toHaveBeenCalledWith(window.location.href);
});
