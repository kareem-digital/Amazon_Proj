import { describe, expect, it, vi } from "vitest";

import { ApiError } from "@/lib/api/errors";
import { createHttpClient } from "@/lib/api/http";

const BASE_URL = "http://api.test/api/v1";

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

describe("createHttpClient", () => {
  it("resolves paths against the base URL and parses JSON", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({ status: "ok" }));
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });

    await expect(http.request("/health")).resolves.toEqual({ status: "ok" });
    expect(fetchImpl).toHaveBeenCalledWith(
      `${BASE_URL}/health`,
      expect.objectContaining({ method: "GET" }),
    );
  });

  it("joins the URL cleanly regardless of slashes", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({}));
    const http = createHttpClient({ baseUrl: `${BASE_URL}/`, fetchImpl });

    await http.request("health");

    expect(fetchImpl).toHaveBeenCalledWith(
      `${BASE_URL}/health`,
      expect.anything(),
    );
  });

  it("attaches a correlation header and JSON-encodes the body", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({}));
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });

    await http.request("/sessions", { body: { message: "hi" } });

    const init = fetchImpl.mock.calls[0][1] as RequestInit;
    const headers = init.headers as Record<string, string>;
    expect(headers["X-Request-ID"]).toEqual(expect.any(String));
    expect(headers["X-Request-ID"]).not.toHaveLength(0);
    expect(headers["Content-Type"]).toBe("application/json");
    expect(init.method).toBe("POST");
    expect(init.body).toBe(JSON.stringify({ message: "hi" }));
  });

  it("gets a fresh bearer token immediately before dispatch", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({}));
    const accessToken = vi.fn().mockResolvedValue("short-lived-token");
    const http = createHttpClient({
      baseUrl: BASE_URL,
      fetchImpl,
      accessToken,
    });

    await http.request("/sessions");

    expect(accessToken).toHaveBeenCalledOnce();
    expect(fetchImpl.mock.calls[0][1]?.headers).toMatchObject({
      Authorization: "Bearer short-lived-token",
    });
  });

  it("maps a FastAPI error body onto ApiError", async () => {
    const fetchImpl = vi
      .fn()
      .mockResolvedValue(jsonResponse({ detail: "Session not found" }, 404));
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });

    const error = await http.request("/sessions/1").catch((cause) => cause);

    expect(error).toBeInstanceOf(ApiError);
    expect(error).toMatchObject({
      status: 404,
      code: "http_404",
      message: "Session not found",
    });
    expect((error as ApiError).isNetworkError).toBe(false);
  });

  it("normalizes a transport failure into a network ApiError", async () => {
    const fetchImpl = vi.fn().mockRejectedValue(new TypeError("Failed to fetch"));
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });

    const error = await http.request("/health").catch((cause) => cause);

    expect(error).toBeInstanceOf(ApiError);
    expect(error).toMatchObject({ status: 0, code: "network_error" });
    expect((error as ApiError).isNetworkError).toBe(true);
  });

  it("reports a timeout as an ApiError rather than an abort", async () => {
    const fetchImpl = vi.fn(
      (_url: RequestInfo | URL, init?: RequestInit) =>
        new Promise<Response>((_resolve, reject) => {
          init?.signal?.addEventListener("abort", () =>
            reject(new DOMException("Aborted", "AbortError")),
          );
        }),
    );
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl, timeoutMs: 5 });

    const error = await http.request("/health").catch((cause) => cause);

    expect(error).toBeInstanceOf(ApiError);
    expect(error).toMatchObject({ code: "timeout" });
  });

  it("re-throws a caller abort untouched so it stays control flow", async () => {
    const fetchImpl = vi.fn(
      (_url: RequestInfo | URL, init?: RequestInit) =>
        new Promise<Response>((_resolve, reject) => {
          init?.signal?.addEventListener("abort", () =>
            reject(new DOMException("Aborted", "AbortError")),
          );
        }),
    );
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });
    const controller = new AbortController();

    const pending = http
      .request("/health", { signal: controller.signal })
      .catch((cause) => cause);
    controller.abort();
    const error = await pending;

    expect(error).not.toBeInstanceOf(ApiError);
    expect(error).toMatchObject({ name: "AbortError" });
  });

  it("never dispatches when the caller's signal is already aborted", async () => {
    // linkSignals has to propagate an already-aborted signal up front; without
    // that, a cancelled request still hits the network.
    const fetchImpl = vi.fn(
      (_url: RequestInfo | URL, init?: RequestInit) =>
        new Promise<Response>((_resolve, reject) => {
          if (init?.signal?.aborted) {
            reject(new DOMException("Aborted", "AbortError"));
            return;
          }
          init?.signal?.addEventListener("abort", () =>
            reject(new DOMException("Aborted", "AbortError")),
          );
        }),
    );
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });

    const error = await http
      .request("/health", { signal: AbortSignal.abort() })
      .catch((cause) => cause);

    expect(error).not.toBeInstanceOf(ApiError);
    expect(error).toMatchObject({ name: "AbortError" });
  });

  it("hands back raw text when the response is not JSON", async () => {
    const fetchImpl = vi
      .fn()
      .mockResolvedValue(new Response("plain text, not JSON", { status: 200 }));
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });

    await expect(http.request("/health")).resolves.toBe("plain text, not JSON");
  });

  it("uses a non-JSON error body as the message", async () => {
    // nginx and other proxies in front of FastAPI return HTML or plain text;
    // the message has to stay useful rather than collapsing to the status.
    const fetchImpl = vi
      .fn()
      .mockResolvedValue(new Response("Bad Gateway", { status: 502 }));
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });

    const error = await http.request("/health").catch((cause) => cause);

    expect(error).toMatchObject({
      status: 502,
      code: "http_502",
      message: "Bad Gateway",
    });
  });

  it("falls back to a status message when the error body says nothing useful", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({ foo: 1 }, 500));
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });

    const error = await http.request("/health").catch((cause) => cause);

    expect(error).toMatchObject({
      status: 500,
      message: "Request failed with status 500",
    });
  });

  it("prefers a server-supplied error code over the derived one", async () => {
    const fetchImpl = vi
      .fn()
      .mockResolvedValue(
        jsonResponse({ detail: "Nope", code: "session_expired" }, 403),
      );
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });

    const error = await http.request("/health").catch((cause) => cause);

    expect(error).toMatchObject({ code: "session_expired", status: 403 });
  });

  it("returns undefined for a 204, which has no body to parse", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(new Response(null, { status: 204 }));
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });

    await expect(http.request("/sessions/1", { method: "DELETE" })).resolves
      .toBeUndefined();
  });

  it("echoes the server's request id back on the error, so logs line up", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ detail: "boom" }), {
        status: 500,
        headers: { "X-Request-ID": "server-side-id" },
      }),
    );
    const http = createHttpClient({ baseUrl: BASE_URL, fetchImpl });

    const error = await http.request("/health").catch((cause) => cause);

    expect(error).toMatchObject({ requestId: "server-side-id" });
  });
});
