import { render, renderHook } from "@testing-library/react";
import type { ReactNode } from "react";
import { describe, expect, it, vi } from "vitest";

import {
  AgentClientProvider,
  useAgentClient,
} from "@/lib/agent/agent-client-context";
import type { AgentClient } from "@/lib/agent/types";
import { textBlock } from "@/lib/chat";
import { stubAgentClient } from "@/test/factories";

function Consumer() {
  useAgentClient();
  return null;
}

describe("AgentClientProvider", () => {
  it("hands the injected client to everything beneath it", () => {
    const client = stubAgentClient();
    const { result } = renderHook(() => useAgentClient(), {
      wrapper: ({ children }: { children: ReactNode }) => (
        <AgentClientProvider client={client}>{children}</AgentClientProvider>
      ),
    });

    expect(result.current).toBe(client);
  });

  it("builds an HTTP transport when the host supplies no client", async () => {
    const fetchImpl = vi.fn(
      async () =>
        new Response(
          JSON.stringify({
            session_id: "s-1",
            reply: "from the server",
            stage: null,
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        ),
    );
    vi.stubGlobal("fetch", fetchImpl);

    const { result } = renderHook(() => useAgentClient(), {
      wrapper: ({ children }: { children: ReactNode }) => (
        <AgentClientProvider
          advertiserId="adv-1"
          accessToken={async () => "access-token"}
        >
          {children}
        </AgentClientProvider>
      ),
    });

    const reply = await result.current.send({
      clientMessageId: "c-1",
      content: [textBlock("hi")],
    });

    expect(fetchImpl).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        headers: expect.objectContaining({
          Authorization: "Bearer access-token",
          "Vowmade-Advertiser-Id": "adv-1",
        }),
      }),
    );
    expect(reply.content).toEqual([textBlock("from the server")]);

    vi.unstubAllGlobals();
  });

  it("keeps one client instance across re-renders", () => {
    // use-chat's `send` callback depends on [agentClient]; a fresh instance
    // per render would silently re-create that callback every turn.
    const { result, rerender } = renderHook(() => useAgentClient(), {
      wrapper: ({ children }: { children: ReactNode }) => (
        <AgentClientProvider>{children}</AgentClientProvider>
      ),
    });
    const first = result.current;

    rerender();

    expect(result.current).toBe(first);
  });

  it("rebuilds the client when the config it was derived from changes", () => {
    // Driven through `render` rather than `renderHook`, because renderHook's
    // `initialProps` reach the callback, not the wrapper — the provider props
    // are exactly what has to change here.
    const seen: AgentClient[] = [];
    function Probe() {
      seen.push(useAgentClient());
      return null;
    }
    const tree = (apiBaseUrl: string) => (
      <AgentClientProvider apiBaseUrl={apiBaseUrl}>
        <Probe />
      </AgentClientProvider>
    );

    const { rerender } = render(tree("https://one.test"));
    rerender(tree("https://two.test"));

    expect(seen).toHaveLength(2);
    expect(seen[1]).not.toBe(seen[0]);
  });
});

describe("useAgentClient", () => {
  it("throws a directed error when used outside a provider", () => {
    // React logs the render error itself; silence it so the failure output
    // stays readable.
    const consoleError = vi
      .spyOn(console, "error")
      .mockImplementation(() => {});

    expect(() => render(<Consumer />)).toThrowError(
      /must be used inside an <AgentClientProvider>/,
    );

    consoleError.mockRestore();
  });
});

describe("the transport contract", () => {
  it("is satisfied by any object with a send method", () => {
    // Nothing above lib/agent may depend on a concrete implementation.
    const custom: AgentClient = {
      send: async () => ({ content: [textBlock("from the host")] }),
    };
    const { result } = renderHook(() => useAgentClient(), {
      wrapper: ({ children }: { children: ReactNode }) => (
        <AgentClientProvider client={custom}>{children}</AgentClientProvider>
      ),
    });

    expect(result.current).toBe(custom);
  });
});
