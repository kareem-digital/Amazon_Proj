export { config, chatLimits } from "@/lib/config/config";
export type { AppConfig, AuthMode, OAuthConfig } from "@/lib/config/config";
