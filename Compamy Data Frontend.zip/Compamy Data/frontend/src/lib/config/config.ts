/** Runtime configuration. Environment variables only — never hard-coded secrets.
 *  Only VITE_* values are readable from the browser bundle. */

function readEnv(key: keyof ImportMetaEnv): string | undefined {
  const value = import.meta.env[key];
  return value === undefined || value === "" ? undefined : value;
}

export type AuthMode = "oidc" | "local";

function readAuthMode(): AuthMode {
  const value = readEnv("VITE_AUTH_MODE") ?? "oidc";
  if (value !== "oidc" && value !== "local") {
    throw new Error("VITE_AUTH_MODE must be either 'oidc' or 'local'");
  }
  return value;
}

export interface AppConfig {
  appName: string;
  appTagline: string;
  /** FastAPI backend (see ../app/config.py), or mock-server for local dev. */
  apiBaseUrl: string;
  /** Per-request ceiling applied by the HTTP transport. */
  requestTimeoutMs: number;
  /** `local` skips browser OIDC; the backend independently enforces its mode. */
  authMode: AuthMode;
  /** OAuth client settings for Authorization Code + PKCE. */
  oauth: OAuthConfig;
  /** Active advertiser supplied by the host (a local fallback is env-only). */
  advertiserId?: string;
}

export interface OAuthConfig {
  authority: string;
  clientId: string;
  resource: string;
  /** Full-page callback used by the standalone application. */
  redirectUri: string;
  /** Popup callback used when the widget is embedded in VOW. */
  popupRedirectUri: string;
  scope: string;
}

export const config: AppConfig = {
  appName: "VOW Agent",
  appTagline: "Campaign planning assistant",
  apiBaseUrl: readEnv("VITE_API_BASE_URL") ?? "http://localhost:8001/api/v1",
  requestTimeoutMs: 30_000,
  authMode: readAuthMode(),
  oauth: {
    authority:
      readEnv("VITE_VOW_OIDC_AUTHORITY") ??
      "http://localhost:8000/api/identity/oauth2",
    clientId: readEnv("VITE_VOW_OAUTH_CLIENT_ID") ?? "vow-agent-mfe",
    resource:
      readEnv("VITE_VOW_AGENT_RESOURCE") ?? "http://localhost:8001",
    redirectUri:
      readEnv("VITE_VOW_OAUTH_REDIRECT_URI") ??
      "http://localhost:3001/agent/oauth/login-callback",
    popupRedirectUri:
      readEnv("VITE_VOW_OAUTH_POPUP_REDIRECT_URI") ??
      "http://localhost:3001/agent/oauth/callback",
    scope: readEnv("VITE_VOW_OAUTH_SCOPE") ?? "openid read",
  },
  advertiserId:
    readEnv("VITE_ADVERTISER_ID") ??
    (import.meta.env.DEV ? "dev-advertiser-0001" : undefined),
};

export const chatLimits = {
  /** Client-side guard so an oversized payload never reaches the agent. */
  maxMessageLength: 2000,
  /** Trimmed history handed to the agent with each turn. */
  maxHistoryMessages: 20,
} as const;
