"""The node that stops and asks.

Reached whenever a stage recorded something in `awaiting`. It turns that list into one
question and ends the turn - the graph does not continue until the trader replies.

Asks for everything outstanding at once. Drip-feeding one question per turn would be four
round trips to start a plan, which is exactly the wizard experience the agent is meant to
replace.

**No model call.** This node used to send the list to the LLM to have it reworded, and three
things were wrong with that:

    it cost a whole turn    ~1081 ms average across 12 calls, on top of the extract call, so
                            a blocked turn spent ~2.5 s waiting on two round trips
    it changed the content  given the one-item list "a flight that has not already finished -
                            2023-10-01 to 2023-10-31 is in the past", gpt-4o-mini dropped the
                            reason and asked for the dates, the audience, the budget and the
                            channels. Three requirements invented from a list of one, and the
                            budget was already on the card
    the words stopped       the UI renders these as option cards, not prose. Once the
    mattering               elicitation format lands, "10 seconds / 15 seconds / 20 seconds /
                            30 seconds" are buttons - so we were paying a model to phrase a
                            sentence the trader will not read

What is asked was always computed here - `missing_basics` decides it. Now the phrasing is too,
which makes the whole node deterministic and testable: the same `awaiting` list produces the
same words every time.
"""

from __future__ import annotations

import logging

from app.agent.gates import BASICS, NO_AUDIENCE, NO_INVENTORY
from app.agent.state import PlanningAgentState
from app.core.logging import kv

logger = logging.getLogger(__name__)

# The vocabulary the gate owns: short noun clauses, written to be joined into a sentence.
#
# **Anything NOT in here was computed from the trader's own values, and carries its own
# clause.** Joining one of those into the list produces a sentence that falls over:
#
#   "I need a flight that has not already finished - 2023-10-01 to 2023-10-31 is in the past,
#    and today is 2026-08-14 and the budget. Could you tell me?"
#
# So a computed reason gets a sentence of its own, before the question about what is simply
# absent. Which is also the right order to read them in: a trader who typed a date needs to
# hear what was wrong with it before being asked for another one.
_FIXED_LABELS = frozenset({label for _key, label in BASICS} | {NO_INVENTORY, NO_AUDIENCE})


def _joined(items: list[str]) -> str:
    """"a and b" / "a, b and c" - the list as a person would say it."""
    if len(items) == 1:
        return items[0]
    return f"{', '.join(items[:-1])} and {items[-1]}"


def _question(missing: list[str]) -> str:
    """One question for whatever is outstanding.

    Two shapes, because two items read better as a sentence and four read better as a list.
    The labels are written to slot into both - "the budget", "the start and end dates" - which
    is why they are phrased as noun clauses in `gates.BASICS` rather than as questions.
    """
    if len(missing) <= 2:
        return f"Before I can carry on I need {_joined(missing)}. Could you tell me?"

    lines = ["Before I can carry on I need a few more details:", ""]
    lines += [f"- {item}" for item in missing]
    lines += ["", "Send them over and I'll put the plan together."]
    return "\n".join(lines)


async def ask_for_missing(state: PlanningAgentState) -> dict:
    """Ask for whatever the previous stage recorded as outstanding."""
    missing = state.get("awaiting") or []
    if not missing:
        # Defensive: the router should never route here with nothing to ask.
        return {}

    # A computed reason is stated on its own; the plain gaps become one question.
    stated = [item for item in missing if item not in _FIXED_LABELS]
    gaps = [item for item in missing if item in _FIXED_LABELS]

    # **Verbatim, with no prefix.** The gate's own labels are noun clauses that need a sentence
    # around them ("the budget" -> "I need the budget"); a computed entry already IS one, and
    # wrapping it produced "I need I cannot plan for CN - VOW does not sell CTV inventory
    # there.." - two sentences fused, stopped twice. `_grounding._as_sentence` is what
    # guarantees they arrive complete.
    parts = list(stated)
    if gaps:
        parts.append(_question(gaps))
    else:
        # Only a reason, nothing else outstanding. `missing` was non-empty so `stated` holds
        # it - and a message that only states a problem leaves the trader nothing to do.
        parts.append("What would you like instead?")

    logger.info("gate.blocked", extra=kv(awaiting=missing, stated=len(stated), calls=0))

    return {"messages": [{"role": "assistant", "content": "\n\n".join(parts)}]}
