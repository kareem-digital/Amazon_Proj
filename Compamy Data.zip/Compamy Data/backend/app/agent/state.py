"""The state carried through the CTV planning graph.

Field names come verbatim from `PlanningAgentState` in
`VOW_Strategy_Schema_v2.md` section 5, which is the cross-lane contract. Only
the fields the current four nodes touch are declared - the remaining ones
(approval, creative, tracking, credit, activation) land with their stages.

Partial by design, not by accident: `scripts/schema_drift.py` reports the gap
so it stays visible rather than being forgotten.
"""

from typing import Annotated

from langgraph.graph.message import add_messages
from typing_extensions import TypedDict


class PlanningAgentState(TypedDict, total=False):
    """State for the CTV planning flow.

    `total=False` because nodes fill this progressively - a state part-way
    through the graph is legitimately incomplete, and every node returns only
    the keys it owns for LangGraph to merge.
    """

    # --- Conversation ---
    messages: Annotated[list, add_messages]

    # --- Session context ---
    advertiser_id: str
    session_id: str
    current_stage: str

    # --- Basics (step 1) ---
    strategy_name: str | None
    flight_dates: dict | None  # {"lower": "YYYY-MM-DD", "upper": "YYYY-MM-DD"}
    markets: list[str]  # ISO country codes
    durations: list[str]  # creative durations in seconds, as strings
    primary_currency: str
    goal: str  # fixed AWARENESS for CTV
    kpi: str  # reach or frequency
    market_budgets: list[dict]  # [{market, budget, base_bid}]

    # --- Inventory (step 2) ---
    # Providers the trader named, anywhere in the conversation. Empty means no
    # preference expressed, so the inventory stage should offer a choice rather
    # than confirm one.
    preferred_providers: list[str]
    inventory_tier: str | None  # dominant tier, drives downstream branching
    selected_deals: list[dict]
    # Providers available in this market that the trader did NOT choose, so a
    # confirmation can show the way out.
    inventory_alternatives: list[str]

    # --- Audiences (step 4) ---
    audience_options: list[dict]  # always three: narrow / balanced / wide
    chosen_audience: dict | None

    # --- Forecast (step 6) ---
    forecast: dict | None  # carries is_available for the honesty rule

    # --- Flow control ---
    # Which step the conversation has reached. Distinct from `current_stage`,
    # which extract_fields resets on every turn: this one only moves forward,
    # and only the stage nodes write it. It is what makes the agent take one
    # step per turn instead of running the whole plan before it speaks.
    stage_cursor: str

    # Plan fields the trader HAS filled in but VOW cannot accept - `["markets"]` when they
    # named China. Distinct from `awaiting`, which is what is still blank, and the difference
    # decides what to put on screen: a blank field gets an input, a rejected one gets the
    # values that would be valid instead.
    #
    # A list of field names rather than the reasons: the reasons are already in `awaiting`,
    # where `ask_for_missing` says them. Two copies of the same sentence would drift.
    rejected_fields: list[str]

    # What the agent is waiting for the trader to supply. Non-empty means the
    # graph stops at the current stage and asks instead of pressing on.
    # Not in schema v2 yet - the adaptive flow needs it, so the contract should
    # pick it up at the next revision.
    awaiting: list[str]

    # --- Errors ---
    validation_errors: list[str]


# Kept so nothing that imported the old name breaks mid-refactor.
PlanningState = PlanningAgentState
