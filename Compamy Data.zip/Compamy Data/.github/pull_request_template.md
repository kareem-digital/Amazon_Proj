## Ticket

<!-- e.g. PLT-04 -->

## What this changes

<!-- One or two sentences. -->

## Definition of Done

<!-- Copy the checkboxes from the ticket and tick them off. -->

- [ ]
- [ ]

## Checklist

- [ ] Tests added or updated
- [ ] CI green
- [ ] No secrets committed
- [ ] Docs updated if behaviour changed
