﻿import { afterEach, describe, expect, it, vi } from "vitest";

import { chatLimits } from "@/lib/config";
import { cn, createId, formatTime, normalizeInput } from "@/lib/utils";

/** Built rather than written literally: a raw NUL, BELL or DEL in a source
 *  file does not survive editors, diffs or copy/paste. */
const NUL = String.fromCharCode(0);
const BELL = String.fromCharCode(7);
const DEL = String.fromCharCode(127);

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("cn", () => {
  it("joins the truthy class names and drops the rest", () => {
    expect(cn("chat", false, null, undefined, "chat-end")).toBe("chat chat-end");
  });

  it("returns an empty string when every class is falsy", () => {
    expect(cn(false, null, undefined)).toBe("");
  });
});

describe("createId", () => {
  it("uses crypto.randomUUID when the platform provides it", () => {
    vi.stubGlobal("crypto", { randomUUID: () => "11111111-2222-3333" });

    expect(createId()).toBe("11111111-2222-3333");
  });

  it("falls back to a timestamp id when crypto.randomUUID is unavailable", () => {
    // Older embedded WebViews, and any host page served over a non-secure
    // context, expose `crypto` without `randomUUID`.
    vi.stubGlobal("crypto", {});

    expect(createId()).toMatch(/^[a-z0-9]+-[a-z0-9]{1,8}$/);
  });

  it("returns a different id on every call", () => {
    expect(createId()).not.toBe(createId());
  });
});

describe("normalizeInput", () => {
  it("strips control characters from the payload", () => {
    expect(normalizeInput(`bud${NUL}get${BELL}`)).toBe("budget");
  });

  it("keeps tabs and line breaks, which are legitimate in a brief", () => {
    expect(normalizeInput("line one\n\tline two")).toBe("line one\n\tline two");
  });

  it("keeps a carriage return, so pasted Windows text survives intact", () => {
    expect(normalizeInput("line one\r\nline two")).toBe("line one\r\nline two");
  });

  it("drops DEL as well as the C0 range", () => {
    expect(normalizeInput(`a${DEL}b`)).toBe("ab");
  });

  it("trims surrounding whitespace after stripping", () => {
    // Order matters: a leading control character must not defeat the trim.
    expect(normalizeInput(`${NUL}   Plan a campaign   `)).toBe(
      "Plan a campaign",
    );
  });

  it("caps input at the configured maximum length", () => {
    const oversized = "x".repeat(chatLimits.maxMessageLength + 500);

    expect(normalizeInput(oversized)).toHaveLength(chatLimits.maxMessageLength);
  });

  it("returns an empty string for whitespace-only input", () => {
    // This is what makes use-chat's blank guard work.
    expect(normalizeInput("   \n\t  ")).toBe("");
  });

  it("leaves ordinary text untouched", () => {
    expect(normalizeInput("Plan a CTV campaign — £250k, Q4")).toBe(
      "Plan a CTV campaign — £250k, Q4",
    );
  });
});

describe("formatTime", () => {
  it("formats an epoch timestamp as a local hour and minute", () => {
    const timestamp = Date.UTC(2024, 0, 1, 9, 30);

    // Asserted against the platform rather than a literal: CI runs UTC and no
    // development machine does.
    expect(formatTime(timestamp)).toBe(
      new Date(timestamp).toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
    );
    expect(formatTime(timestamp)).toMatch(/\d{1,2}:\d{2}/);
  });
});
