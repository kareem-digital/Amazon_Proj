import { chatLimits } from "@/lib/config";

/** Minimal class-name joiner — avoids pulling in clsx/tailwind-merge. */
export function cn(
  ...classes: Array<string | false | null | undefined>
): string {
  return classes.filter(Boolean).join(" ");
}

export function createId(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

const TAB = 9;
const LINE_FEED = 10;
const CARRIAGE_RETURN = 13;
const SPACE = 32;
const DELETE = 127;

/** Drops control characters while keeping tabs and line breaks. */
function stripControlChars(value: string): string {
  let result = "";
  for (const char of value) {
    const code = char.codePointAt(0) ?? 0;
    const isAllowedWhitespace =
      code === TAB || code === LINE_FEED || code === CARRIAGE_RETURN;
    if (isAllowedWhitespace || (code >= SPACE && code !== DELETE)) {
      result += char;
    }
  }
  return result;
}

/**
 * Client-side input hygiene: strip control characters, trim surrounding
 * whitespace and cap the length. React escapes content on render, so this
 * guards the payload rather than the DOM.
 */
export function normalizeInput(value: string): string {
  return stripControlChars(value).trim().slice(0, chatLimits.maxMessageLength);
}

export function formatTime(timestamp: number): string {
  return new Date(timestamp).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });
}
