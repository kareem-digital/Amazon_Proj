import { afterEach, describe, expect, it, vi } from "vitest";

/**
 * `config` is built once at module-evaluation time from `import.meta.env`, so
 * each case has to re-import the module after stubbing rather than reading the
 * statically-imported object. `vi.resetModules()` clears the registry for
 * everything, which is why these cases live in their own file.
 */
async function loadConfig() {
  vi.resetModules();
  return (await import("@/lib/config")).config;
}

afterEach(() => {
  vi.unstubAllEnvs();
  vi.resetModules();
});

describe("config", () => {
  it("uses VITE_API_BASE_URL when the host provides one", async () => {
    vi.stubEnv("VITE_API_BASE_URL", "https://api.example.test/api/v1");

    await expect(loadConfig()).resolves.toMatchObject({
      apiBaseUrl: "https://api.example.test/api/v1",
    });
  });

  it("falls back to mock-server when the base URL is unset", async () => {
    vi.stubEnv("VITE_API_BASE_URL", undefined);

    await expect(loadConfig()).resolves.toMatchObject({
      apiBaseUrl: "http://localhost:4100/api/v1",
    });
  });

  it("treats an empty environment variable as unset", async () => {
    // An unset var and a var set to "" arrive identically from a .env file, and
    // "" as a base URL would silently produce same-origin requests.
    vi.stubEnv("VITE_API_BASE_URL", "");

    await expect(loadConfig()).resolves.toMatchObject({
      apiBaseUrl: "http://localhost:4100/api/v1",
    });
  });

  it("caps every request with a timeout the transport can enforce", async () => {
    await expect(loadConfig()).resolves.toMatchObject({
      requestTimeoutMs: 30_000,
    });
  });
});

describe("chatLimits", () => {
  it("pins the limits the composer, normalizeInput and the counter all share", async () => {
    vi.resetModules();
    const { chatLimits } = await import("@/lib/config");

    expect(chatLimits.maxMessageLength).toBe(2000);
    expect(chatLimits.maxHistoryMessages).toBe(20);
  });
});
