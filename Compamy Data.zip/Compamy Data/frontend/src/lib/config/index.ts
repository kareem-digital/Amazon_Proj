export { config, chatLimits } from "@/lib/config/config";
export type { AppConfig } from "@/lib/config/config";
