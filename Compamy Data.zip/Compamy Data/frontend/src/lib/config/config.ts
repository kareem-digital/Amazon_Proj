/** Runtime configuration. Environment variables only — never hard-coded secrets.
 *  Only VITE_* values are readable from the browser bundle. */

function readEnv(key: keyof ImportMetaEnv): string | undefined {
  const value = import.meta.env[key];
  return value === undefined || value === "" ? undefined : value;
}

export interface AppConfig {
  appName: string;
  appTagline: string;
  /** FastAPI backend (see ../app/config.py), or mock-server for local dev. */
  apiBaseUrl: string;
  /** Per-request ceiling applied by the HTTP transport. */
  requestTimeoutMs: number;
}

export const config: AppConfig = {
  appName: "VOW Agent",
  appTagline: "Campaign planning assistant",
  // Defaults to mock-server: the backend exposes only /health today, so
  // pointing at :8000 has to be deliberate via VITE_API_BASE_URL.
  apiBaseUrl: readEnv("VITE_API_BASE_URL") ?? "http://localhost:4100/api/v1",
  requestTimeoutMs: 30_000,
};

export const chatLimits = {
  /** Client-side guard so an oversized payload never reaches the agent. */
  maxMessageLength: 2000,
  /** Trimmed history handed to the agent with each turn. */
  maxHistoryMessages: 20,
} as const;
