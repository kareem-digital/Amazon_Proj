import type { ReachForecast, StrategyPlan } from "@/types/strategy";

/* Stand-in plan state for the workspace layout. The agent does not emit plan
 * structure yet, so this is what the panel renders until it does — the same
 * role `mock-server/` plays for the chat endpoint. Delete once the plan comes
 * off the wire; nothing outside `VowAgentWidget` imports it. */

/** Curve points are normalised 0–1 with the origin at the bottom-left, so the
 *  chart owns every pixel. Traced off the design's forecast. */
export const REACH_FORECAST: ReachForecast = {
  stats: [
    { label: "Unique reach", value: "~2.4M" },
    { label: "Reached", value: "68%" },
    { label: "Frequency", value: "3.2×" },
    { label: "Impr.", value: "7.6M" },
  ],
  curve: [
    { x: 0, y: 0 },
    { x: 0.121, y: 0.423 },
    { x: 0.218, y: 0.519 },
    { x: 0.345, y: 0.635 },
    { x: 0.564, y: 0.721 },
    { x: 0.715, y: 0.75 },
    { x: 0.891, y: 0.76 },
    { x: 1, y: 0.769 },
  ],
  ceiling: 1,
  ceilingLabel: "Addressable audience 3.5M",
  peakLabel: "~2.4M",
  axisLabels: { x: "Budget", y: "Unique reach" },
  xTicks: ["£0", "£12k", "£24k", "£36k", "£48k"],
  yTicks: ["0", "1M", "2M", "3.5M"],
  updatedLabel: "Updated just now",
};

export const DRAFT_PLAN: StrategyPlan = {
  name: "New strategy",
  status: "draft",
  completion: 15,
  stages: [
    {
      id: "basic-details",
      title: "Basic details",
      status: "in-progress",
      isOpen: true,
      properties: [
        { label: "Brand", value: "Mega Toothpaste" },
        { label: "Markets", value: "UK · USA · France" },
        { label: "Flight", value: "02.12.2025 – 20.11.2026 · 353 days" },
        { label: "Creative", value: null },
      ],
    },
    { id: "goals", title: "Goals, KPI & bid", status: "next" },
    { id: "inventory", title: "CTV inventory", status: "pending" },
    { id: "targeting", title: "Targeting", status: "optional" },
  ],
  lockedStages: [
    { id: "creatives", title: "Creatives", status: "locked" },
    { id: "tracking", title: "Tracking setup", status: "locked" },
    { id: "credit", title: "Credit check", status: "locked" },
  ],
  forecast: null,
};
