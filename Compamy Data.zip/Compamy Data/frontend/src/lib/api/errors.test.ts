import { describe, expect, it } from "vitest";

import { ApiError, isAbortError } from "@/lib/api/errors";

describe("ApiError", () => {
  it("defaults to a status of 0 and an unknown error code", () => {
    const error = new ApiError("something went wrong");

    expect(error.status).toBe(0);
    expect(error.code).toBe("unknown_error");
    expect(error.requestId).toBeUndefined();
    expect(error.body).toBeUndefined();
  });

  it("carries the status, code, request id and parsed body it was given", () => {
    const error = new ApiError("not found", {
      status: 404,
      code: "http_404",
      requestId: "req-123",
      body: { detail: "No such session" },
    });

    expect(error).toMatchObject({
      status: 404,
      code: "http_404",
      requestId: "req-123",
      body: { detail: "No such session" },
    });
  });

  it("preserves the underlying cause", () => {
    const cause = new TypeError("Failed to fetch");

    expect(new ApiError("network", { cause }).cause).toBe(cause);
  });

  it("reports a network error when the request never reached the server", () => {
    expect(new ApiError("offline", { status: 0 }).isNetworkError).toBe(true);
    expect(new ApiError("boom", { status: 500 }).isNetworkError).toBe(false);
  });

  it("is a real Error named ApiError", () => {
    // Load-bearing: isAbortError and every catch block branch on these.
    const error = new ApiError("boom");

    expect(error).toBeInstanceOf(Error);
    expect(error.name).toBe("ApiError");
    expect(error.message).toBe("boom");
  });
});

describe("isAbortError", () => {
  it("recognises a DOMException abort", () => {
    expect(isAbortError(new DOMException("Aborted", "AbortError"))).toBe(true);
  });

  it("recognises a plain Error named AbortError", () => {
    // The dual guard exists because not every fetch implementation throws a
    // DOMException — some environments throw the plain variety.
    const error = new Error("Aborted");
    error.name = "AbortError";

    expect(isAbortError(error)).toBe(true);
  });

  it("ignores an unrelated DOMException", () => {
    expect(isAbortError(new DOMException("Nope", "NotFoundError"))).toBe(false);
  });

  it("ignores an ApiError, so a real failure still surfaces", () => {
    expect(isAbortError(new ApiError("boom", { status: 500 }))).toBe(false);
  });

  it("ignores values that are not errors at all", () => {
    expect(isAbortError(null)).toBe(false);
    expect(isAbortError(undefined)).toBe(false);
    expect(isAbortError("AbortError")).toBe(false);
    expect(isAbortError({ name: "AbortError" })).toBe(false);
  });
});
