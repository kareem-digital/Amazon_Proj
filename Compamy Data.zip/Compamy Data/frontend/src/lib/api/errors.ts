/**
 * Every failure crossing the API boundary surfaces as one of two things:
 * an `ApiError`, or an abort. Callers never have to distinguish a network
 * failure from a 500 from a malformed body unless they want to.
 */
export class ApiError extends Error {
  /** HTTP status, or 0 when the request never reached the server. */
  readonly status: number;
  /** Machine-readable code: backend-supplied when available, else derived. */
  readonly code: string;
  /** Correlates with the X-Request-ID sent on the request. */
  readonly requestId?: string;
  /** Parsed response body, when there was one. */
  readonly body?: unknown;

  constructor(
    message: string,
    options: {
      status?: number;
      code?: string;
      requestId?: string;
      body?: unknown;
      cause?: unknown;
    } = {},
  ) {
    super(message, { cause: options.cause });
    this.name = "ApiError";
    this.status = options.status ?? 0;
    this.code = options.code ?? "unknown_error";
    this.requestId = options.requestId;
    this.body = options.body;
  }

  /** True when the server was never reached (offline, DNS, CORS, timeout). */
  get isNetworkError(): boolean {
    return this.status === 0;
  }
}

/**
 * Aborts are control flow, not failures — `use-chat` cancels in-flight
 * requests on reset and unmount, and those must not surface as errors.
 */
export function isAbortError(cause: unknown): boolean {
  return (
    (cause instanceof DOMException && cause.name === "AbortError") ||
    (cause instanceof Error && cause.name === "AbortError")
  );
}
