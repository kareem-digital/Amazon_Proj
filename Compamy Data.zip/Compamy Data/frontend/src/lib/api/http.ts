import { ApiError, isAbortError } from "@/lib/api/errors";
import { createId } from "@/lib/utils";

export interface HttpRequestInit {
  method?: string;
  /** Serialized as JSON. Omit for GET/DELETE. */
  body?: unknown;
  headers?: Record<string, string>;
  /** Caller cancellation, composed with the client's timeout. */
  signal?: AbortSignal;
  /** Overrides the client-level timeout for this call. */
  timeoutMs?: number;
}

export interface HttpClient {
  request<T>(path: string, init?: HttpRequestInit): Promise<T>;
}

export interface HttpClientOptions {
  baseUrl: string;
  timeoutMs?: number;
  /** Injectable for tests; defaults to the global fetch. */
  fetchImpl?: typeof fetch;
}

const DEFAULT_TIMEOUT_MS = 30_000;

function joinUrl(baseUrl: string, path: string): string {
  return `${baseUrl.replace(/\/+$/, "")}/${path.replace(/^\/+/, "")}`;
}

/**
 * Composes caller cancellation with the timeout without relying on
 * `AbortSignal.any`, which is missing from some test environments.
 */
function linkSignals(
  controller: AbortController,
  signal: AbortSignal | undefined,
): () => void {
  if (!signal) return () => {};
  if (signal.aborted) {
    controller.abort(signal.reason);
    return () => {};
  }
  const onAbort = () => controller.abort(signal.reason);
  signal.addEventListener("abort", onAbort, { once: true });
  return () => signal.removeEventListener("abort", onAbort);
}

async function readBody(response: Response): Promise<unknown> {
  if (response.status === 204 || response.status === 205) return undefined;
  const text = await response.text();
  if (!text) return undefined;
  try {
    return JSON.parse(text) as unknown;
  } catch {
    // Not JSON — hand back the raw text so error messages stay useful.
    return text;
  }
}

/** Pulls a message/code out of a FastAPI-shaped error body, if present. */
function describeFailure(
  status: number,
  body: unknown,
): { message: string; code?: string } {
  if (body && typeof body === "object") {
    const record = body as Record<string, unknown>;
    const detail = record.detail ?? record.message ?? record.error;
    if (typeof detail === "string") {
      return { message: detail, code: typeof record.code === "string" ? record.code : undefined };
    }
  }
  if (typeof body === "string" && body.trim()) {
    return { message: body.slice(0, 500) };
  }
  return { message: `Request failed with status ${status}` };
}

/**
 * The single transport primitive for the app. Everything that talks to the
 * backend goes through here, so base URL resolution, JSON handling, timeouts,
 * request correlation and error normalization exist in exactly one place.
 */
export function createHttpClient(options: HttpClientOptions): HttpClient {
  const { baseUrl, timeoutMs = DEFAULT_TIMEOUT_MS } = options;
  const doFetch = options.fetchImpl ?? globalThis.fetch.bind(globalThis);

  return {
    async request<T>(path: string, init: HttpRequestInit = {}): Promise<T> {
      const requestId = createId();
      const controller = new AbortController();
      const unlink = linkSignals(controller, init.signal);

      // Distinguishes "we gave up" from "the caller cancelled" once the
      // shared controller has fired.
      let timedOut = false;
      const timer = setTimeout(() => {
        timedOut = true;
        controller.abort();
      }, init.timeoutMs ?? timeoutMs);

      const headers: Record<string, string> = {
        Accept: "application/json",
        "X-Request-ID": requestId,
        ...init.headers,
      };
      if (init.body !== undefined) {
        headers["Content-Type"] = "application/json";
      }

      let response: Response;
      try {
        response = await doFetch(joinUrl(baseUrl, path), {
          method: init.method ?? (init.body === undefined ? "GET" : "POST"),
          headers,
          body: init.body === undefined ? undefined : JSON.stringify(init.body),
          signal: controller.signal,
        });
      } catch (cause) {
        if (timedOut) {
          throw new ApiError(`Request timed out after ${init.timeoutMs ?? timeoutMs}ms`, {
            code: "timeout",
            requestId,
            cause,
          });
        }
        // A genuine caller abort propagates untouched — callers treat it as
        // control flow, not an error.
        if (isAbortError(cause)) throw cause;
        throw new ApiError("Could not reach the server.", {
          code: "network_error",
          requestId,
          cause,
        });
      } finally {
        clearTimeout(timer);
        unlink();
      }

      const body = await readBody(response);

      if (!response.ok) {
        const { message, code } = describeFailure(response.status, body);
        throw new ApiError(message, {
          status: response.status,
          code: code ?? `http_${response.status}`,
          // Prefer the server's echo so client and backend logs line up.
          requestId: response.headers.get("X-Request-ID") ?? requestId,
          body,
        });
      }

      return body as T;
    },
  };
}
