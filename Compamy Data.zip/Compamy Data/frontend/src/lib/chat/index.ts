export {
  blocksToPlainText,
  isOptionsAnswerBlock,
  isOptionsBlock,
  isTextBlock,
  textBlock,
} from "@/lib/chat/blocks";
export {
  collectElicitations,
  findActiveElicitation,
  findElicitation,
  matchesAnswer,
  replaceElicitationBlock,
  resolveAnswerLabels,
  validateSelection,
} from "@/lib/chat/elicitation";
export type {
  DraftSelection,
  ElicitationValidation,
  LocatedElicitation,
  ValidationReason,
} from "@/lib/chat/elicitation";
