import { isOptionsBlock } from "@/lib/chat/blocks";
import { normalizeInput } from "@/lib/utils";
import type {
  ChatMessage,
  ElicitationAnswer,
  OptionsAnswerBlock,
  OptionsBlock,
} from "@/types/chat";

export interface LocatedElicitation {
  messageId: string;
  blockIndex: number;
  block: OptionsBlock;
}

/** Every options block in the transcript, oldest first. */
export function collectElicitations(
  messages: ChatMessage[],
): LocatedElicitation[] {
  const found: LocatedElicitation[] = [];
  for (const message of messages) {
    message.content.forEach((block, blockIndex) => {
      if (isOptionsBlock(block)) {
        found.push({ messageId: message.id, blockIndex, block });
      }
    });
  }
  return found;
}

/**
 * The one interactive elicitation, or null.
 *
 * Deliberately locates the *last* options block and then checks whether the
 * server still calls it pending — not the last pending one. If the newest
 * question is closed, nothing is interactive even when an older one is still
 * open, which is how "only the most recent is answerable" holds without any
 * client-side flag.
 */
export function findActiveElicitation(
  messages: ChatMessage[],
): LocatedElicitation | null {
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    const content = messages[i].content;
    for (let j = content.length - 1; j >= 0; j -= 1) {
      const block = content[j];
      if (!isOptionsBlock(block)) continue;
      return block.status === "pending"
        ? { messageId: messages[i].id, blockIndex: j, block }
        : null;
    }
  }
  return null;
}

export function findElicitation(
  messages: ChatMessage[],
  elicitationId: string,
): OptionsBlock | null {
  return (
    collectElicitations(messages).find(
      (located) => located.block.id === elicitationId,
    )?.block ?? null
  );
}

/**
 * Overwrites an options block with the server's version. Only the message that
 * held it is cloned, so a conflict correction re-renders one bubble.
 */
export function replaceElicitationBlock(
  messages: ChatMessage[],
  block: OptionsBlock,
): ChatMessage[] {
  let replaced = false;
  const next = messages.map((message) => {
    if (!message.content.some((b) => isOptionsBlock(b) && b.id === block.id)) {
      return message;
    }
    replaced = true;
    return {
      ...message,
      content: message.content.map((b) =>
        isOptionsBlock(b) && b.id === block.id ? block : b,
      ),
    };
  });
  return replaced ? next : messages;
}

/**
 * Resolves an answer's option IDs to their human labels for rendering. The
 * model-facing value is not in the domain model at all, so it cannot leak here.
 */
export function resolveAnswerLabels(
  messages: ChatMessage[],
  answer: OptionsAnswerBlock,
): { labels: string[]; customText: string | null } {
  const block = findElicitation(messages, answer.elicitationId);
  const byId = new Map(block?.options.map((o) => [o.id, o.label]) ?? []);
  return {
    labels: answer.selectedOptionIds
      .map((id) => byId.get(id))
      .filter((label): label is string => label !== undefined),
    customText: answer.customText ?? null,
  };
}

export interface DraftSelection {
  optionIds: string[];
  customText: string;
}

export type ValidationReason =
  | "empty"
  | "too_many"
  | "custom_not_allowed"
  | "unknown_option";

export type ElicitationValidation =
  | { ok: true; answer: OptionsAnswerBlock }
  | { ok: false; reason: ValidationReason };

/**
 * The only place an `OptionsAnswerBlock` is constructed. Mirrors the server's
 * validation so an obviously invalid answer never leaves the tab.
 */
export function validateSelection(
  block: OptionsBlock,
  draft: DraftSelection,
): ElicitationValidation {
  const customText = normalizeInput(draft.customText);
  if (customText && !block.allowCustom) {
    return { ok: false, reason: "custom_not_allowed" };
  }

  const known = new Set(block.options.map((option) => option.id));
  if (draft.optionIds.some((id) => !known.has(id))) {
    return { ok: false, reason: "unknown_option" };
  }
  if (block.select === "single" && draft.optionIds.length > 1) {
    return { ok: false, reason: "too_many" };
  }
  if (draft.optionIds.length === 0 && !customText) {
    return { ok: false, reason: "empty" };
  }

  return {
    ok: true,
    answer: {
      type: "options_answer",
      elicitationId: block.id,
      selectedOptionIds: draft.optionIds,
      customText: customText || null,
    },
  };
}

/**
 * Whether the server's recorded answer is the one we just submitted. A 409 that
 * matches is our own double-submit landing twice, not a stale tab, so it is
 * reconciled silently.
 */
export function matchesAnswer(
  recorded: ElicitationAnswer | null | undefined,
  submitted: { optionIds: string[]; customText: string | null },
): boolean {
  if (!recorded) return false;
  const a = [...recorded.selectedOptionIds].sort();
  const b = [...submitted.optionIds].sort();
  return (
    a.length === b.length &&
    a.every((id, i) => id === b[i]) &&
    (recorded.customText ?? null) === (submitted.customText ?? null)
  );
}
