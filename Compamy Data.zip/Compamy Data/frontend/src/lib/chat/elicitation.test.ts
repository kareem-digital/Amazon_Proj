import { describe, expect, it } from "vitest";

import { textBlock } from "@/lib/chat/blocks";
import {
  collectElicitations,
  findActiveElicitation,
  findElicitation,
  matchesAnswer,
  replaceElicitationBlock,
  resolveAnswerLabels,
  validateSelection,
} from "@/lib/chat/elicitation";
import { makeMessage, makeOptionsBlock } from "@/test/factories";

describe("collectElicitations", () => {
  it("returns every options block with where it sits, oldest first", () => {
    const first = makeOptionsBlock({ id: "e-1" });
    const second = makeOptionsBlock({ id: "e-2" });
    const messages = [
      makeMessage({ role: "assistant", content: [textBlock("hi"), first] }),
      makeMessage({ role: "assistant", content: [second] }),
    ];

    expect(collectElicitations(messages)).toEqual([
      { messageId: messages[0].id, blockIndex: 1, block: first },
      { messageId: messages[1].id, blockIndex: 0, block: second },
    ]);
  });

  it("is empty for a transcript of plain prose", () => {
    expect(collectElicitations([makeMessage()])).toEqual([]);
  });
});

describe("findActiveElicitation", () => {
  it("returns the newest question while the server still calls it pending", () => {
    const block = makeOptionsBlock({ status: "pending" });
    const messages = [makeMessage({ role: "assistant", content: [block] })];

    expect(findActiveElicitation(messages)?.block).toBe(block);
  });

  it("returns null when the newest question is closed, even if an older one is open", () => {
    // "Only the most recent is answerable" has to hold without a client-side
    // flag: a closed newest question means nothing is interactive.
    const messages = [
      makeMessage({
        role: "assistant",
        content: [makeOptionsBlock({ id: "e-1", status: "pending" })],
      }),
      makeMessage({
        role: "assistant",
        content: [makeOptionsBlock({ id: "e-2", status: "answered" })],
      }),
    ];

    expect(findActiveElicitation(messages)).toBeNull();
  });

  it("looks past later prose to the last question in the transcript", () => {
    const block = makeOptionsBlock({ status: "pending" });
    const messages = [
      makeMessage({ role: "assistant", content: [block] }),
      makeMessage({ role: "assistant", content: [textBlock("thinking…")] }),
    ];

    expect(findActiveElicitation(messages)?.block).toBe(block);
  });

  it("returns null for an empty transcript", () => {
    expect(findActiveElicitation([])).toBeNull();
  });
});

describe("findElicitation", () => {
  it("finds a block by id and returns null for an unknown one", () => {
    const block = makeOptionsBlock({ id: "e-1" });
    const messages = [makeMessage({ role: "assistant", content: [block] })];

    expect(findElicitation(messages, "e-1")).toBe(block);
    expect(findElicitation(messages, "nope")).toBeNull();
  });
});

describe("replaceElicitationBlock", () => {
  it("swaps in the server's version and clones only the message that held it", () => {
    const prose = makeMessage({ role: "assistant" });
    const question = makeMessage({
      role: "assistant",
      content: [textBlock("pick"), makeOptionsBlock({ id: "e-1" })],
    });
    const server = makeOptionsBlock({ id: "e-1", status: "answered" });

    const next = replaceElicitationBlock([prose, question], server);

    expect(next[1].content[1]).toBe(server);
    expect(next[1]).not.toBe(question);
    // Untouched messages keep their identity, so one bubble re-renders.
    expect(next[0]).toBe(prose);
  });

  it("returns the original array when the block is not in the transcript", () => {
    const messages = [makeMessage()];

    expect(replaceElicitationBlock(messages, makeOptionsBlock())).toBe(
      messages,
    );
  });
});

describe("resolveAnswerLabels", () => {
  it("maps selected ids to their human labels", () => {
    const block = makeOptionsBlock();
    const messages = [makeMessage({ role: "assistant", content: [block] })];

    expect(
      resolveAnswerLabels(messages, {
        type: "options_answer",
        elicitationId: block.id,
        selectedOptionIds: ["opt-twitch", "opt-prime"],
        customText: "and podcasts",
      }),
    ).toEqual({
      labels: ["Twitch", "Prime Video"],
      customText: "and podcasts",
    });
  });

  it("drops ids it cannot resolve rather than rendering them", () => {
    const block = makeOptionsBlock();
    const messages = [makeMessage({ role: "assistant", content: [block] })];

    expect(
      resolveAnswerLabels(messages, {
        type: "options_answer",
        elicitationId: block.id,
        selectedOptionIds: ["opt-prime", "ghost"],
      }),
    ).toEqual({ labels: ["Prime Video"], customText: null });
  });

  it("yields no labels when the elicitation is missing entirely", () => {
    expect(
      resolveAnswerLabels([], {
        type: "options_answer",
        elicitationId: "gone",
        selectedOptionIds: ["opt-prime"],
      }),
    ).toEqual({ labels: [], customText: null });
  });
});

describe("validateSelection", () => {
  it("builds an answer block from a single choice", () => {
    const block = makeOptionsBlock();

    expect(
      validateSelection(block, { optionIds: ["opt-prime"], customText: "" }),
    ).toEqual({
      ok: true,
      answer: {
        type: "options_answer",
        elicitationId: block.id,
        selectedOptionIds: ["opt-prime"],
        customText: null,
      },
    });
  });

  it("accepts several choices for a multi-select", () => {
    const block = makeOptionsBlock({ select: "multi" });
    const result = validateSelection(block, {
      optionIds: ["opt-prime", "opt-twitch"],
      customText: "",
    });

    expect(result.ok && result.answer.selectedOptionIds).toEqual([
      "opt-prime",
      "opt-twitch",
    ]);
  });

  it("rejects more than one choice for a single-select", () => {
    expect(
      validateSelection(makeOptionsBlock(), {
        optionIds: ["opt-prime", "opt-twitch"],
        customText: "",
      }),
    ).toEqual({ ok: false, reason: "too_many" });
  });

  it("rejects an option the question does not offer", () => {
    expect(
      validateSelection(makeOptionsBlock(), {
        optionIds: ["opt-ghost"],
        customText: "",
      }),
    ).toEqual({ ok: false, reason: "unknown_option" });
  });

  it("rejects typed text when the question does not invite it", () => {
    expect(
      validateSelection(makeOptionsBlock({ allowCustom: false }), {
        optionIds: [],
        customText: "something else",
      }),
    ).toEqual({ ok: false, reason: "custom_not_allowed" });
  });

  it("rejects an empty answer", () => {
    expect(
      validateSelection(makeOptionsBlock({ allowCustom: true }), {
        optionIds: [],
        customText: "   ",
      }),
    ).toEqual({ ok: false, reason: "empty" });
  });

  it("normalizes typed text and accepts it on its own", () => {
    const result = validateSelection(makeOptionsBlock({ allowCustom: true }), {
      optionIds: [],
      customText: "  connected TV only  ",
    });

    expect(result.ok && result.answer.customText).toBe("connected TV only");
  });
});

describe("matchesAnswer", () => {
  const submitted = { optionIds: ["opt-prime"], customText: null };

  it("treats an identical record as our own double-submit", () => {
    expect(
      matchesAnswer(
        { selectedOptionIds: ["opt-prime"], customText: null },
        submitted,
      ),
    ).toBe(true);
  });

  it("ignores the order the ids were recorded in", () => {
    expect(
      matchesAnswer(
        { selectedOptionIds: ["b", "a"], customText: null },
        { optionIds: ["a", "b"], customText: null },
      ),
    ).toBe(true);
  });

  it("rejects a different selection, a different text, or no record at all", () => {
    expect(
      matchesAnswer(
        { selectedOptionIds: ["opt-twitch"], customText: null },
        submitted,
      ),
    ).toBe(false);
    expect(
      matchesAnswer(
        { selectedOptionIds: ["opt-prime"], customText: "typed" },
        submitted,
      ),
    ).toBe(false);
    expect(matchesAnswer(null, submitted)).toBe(false);
  });
});
