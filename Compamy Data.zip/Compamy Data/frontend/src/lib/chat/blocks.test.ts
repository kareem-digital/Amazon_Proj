import { describe, expect, it } from "vitest";

import {
  blocksToPlainText,
  isOptionsAnswerBlock,
  isOptionsBlock,
  isTextBlock,
  textBlock,
} from "@/lib/chat/blocks";
import type { MessageBlock, OptionsAnswerBlock } from "@/types/chat";
import { makeOptionsBlock } from "@/test/factories";

const answer: OptionsAnswerBlock = {
  type: "options_answer",
  elicitationId: "e-1",
  selectedOptionIds: ["opt-prime"],
  customText: null,
};

describe("textBlock", () => {
  it("wraps a string as a text block", () => {
    expect(textBlock("hello")).toEqual({ type: "text", text: "hello" });
  });
});

describe("the block guards", () => {
  const blocks: MessageBlock[] = [textBlock("hi"), makeOptionsBlock(), answer];

  it("each narrow to exactly one block type", () => {
    expect(blocks.filter(isTextBlock)).toEqual([textBlock("hi")]);
    expect(blocks.filter(isOptionsBlock)).toEqual([blocks[1]]);
    expect(blocks.filter(isOptionsAnswerBlock)).toEqual([answer]);
  });
});

describe("blocksToPlainText", () => {
  it("joins text blocks with a blank line", () => {
    expect(
      blocksToPlainText([textBlock("Line one"), textBlock("Line two")]),
    ).toBe("Line one\n\nLine two");
  });

  it("contributes nothing for an options block", () => {
    // The projection feeds the legacy `message` field, which becomes prompt
    // context — option labels must never reach it.
    const block = makeOptionsBlock();

    expect(blocksToPlainText([block])).toBe("");
    expect(blocksToPlainText([textBlock("Pick one"), block])).toBe("Pick one");
  });

  it("contributes nothing for a recorded answer", () => {
    expect(blocksToPlainText([answer])).toBe("");
  });

  it("is empty for an empty turn", () => {
    expect(blocksToPlainText([])).toBe("");
  });
});
