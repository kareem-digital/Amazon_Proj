import type {
  MessageBlock,
  OptionsAnswerBlock,
  OptionsBlock,
  TextBlock,
} from "@/types/chat";

export const textBlock = (text: string): TextBlock => ({ type: "text", text });

export const isTextBlock = (block: MessageBlock): block is TextBlock =>
  block.type === "text";

export const isOptionsBlock = (block: MessageBlock): block is OptionsBlock =>
  block.type === "options";

export const isOptionsAnswerBlock = (
  block: MessageBlock,
): block is OptionsAnswerBlock => block.type === "options_answer";

/**
 * Text blocks only, joined by a blank line. Feeds the legacy `message` field
 * on the wire, so an options block contributes nothing — its labels must never
 * reach a field that becomes prompt context.
 */
export function blocksToPlainText(blocks: MessageBlock[]): string {
  return blocks
    .filter(isTextBlock)
    .map((block) => block.text)
    .join("\n\n");
}
