import { afterEach, describe, expect, it, vi } from "vitest";

import { createAgentClient } from "@/lib/agent/create-agent-client";
import { textBlock } from "@/lib/chat";
import { config } from "@/lib/config";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("createAgentClient", () => {
  it("always builds the HTTP transport from the given config", async () => {
    const fetchImpl = vi.fn(
      async (_input: RequestInfo | URL, _init?: RequestInit) =>
        new Response(
          JSON.stringify({
            session_id: "s-1",
            reply: "from the server",
            stage: null,
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        ),
    );
    vi.stubGlobal("fetch", fetchImpl);

    const client = createAgentClient({
      ...config,
      apiBaseUrl: "http://mock.test/api/v1",
    });
    const reply = await client.send({
      clientMessageId: "c-1",
      content: [textBlock("hello")],
    });

    expect(fetchImpl.mock.calls[0][0]).toBe(
      "http://mock.test/api/v1/sessions/chat",
    );
    expect(reply.content).toEqual([textBlock("from the server")]);
  });
});
