/**
 * Wire shapes of the chat API — snake_case, exactly as the backend speaks them.
 * See `docs/elicitation.md` for the contract these mirror.
 *
 * Type declarations only, and imported by `http-agent-client.ts` alone. Nothing
 * else may read these: the mapping to domain types lives in that one file, so
 * the rest of the app stays ignorant of the wire format.
 */
import type { PlanStage } from "@/lib/agent/types";

export interface WireTextBlock {
  type: "text";
  text: string;
}

/**
 * No `value`: the model-facing string stays server-side. The client renders
 * `label` and submits `id`, so it cannot leak or tamper with prompt context.
 * `badge` is presentational only — the design's "Suggested" pill.
 */
export interface WireOptionChoice {
  id: string;
  label: string;
  description?: string | null;
  badge?: string | null;
}

export interface WireElicitationAnswer {
  selected_option_ids: string[];
  custom_text?: string | null;
  /** ISO 8601. */
  answered_at?: string | null;
}

export interface WireOptionsBlock {
  type: "options";
  id: string;
  prompt: string;
  select: "single" | "multi";
  options: WireOptionChoice[];
  allow_custom?: boolean;
  custom_placeholder?: string | null;
  /** Widened on purpose: an unrecognized status narrows to "expired". */
  status: string;
  answer?: WireElicitationAnswer | null;
}

export interface WireOptionsResponseBlock {
  type: "options_response";
  elicitation_id: string;
  selected_option_ids: string[];
  custom_text?: string | null;
}

export type WireBlock =
  | WireTextBlock
  | WireOptionsBlock
  | WireOptionsResponseBlock;

export interface WireChatRequest {
  /** Conversation key. Minted client-side per chat instance — see `http-agent-client`. */
  session_id: string;
  /** Idempotency key. Always sent. */
  client_message_id: string;
  /** Legacy plain-text projection. Omitted on answer-only turns. */
  message?: string;
  content: WireBlock[];
}

export interface WireMessage {
  id?: string;
  role?: "assistant" | "user";
  created_at?: string | null;
  client_message_id?: string | null;
  content: WireBlock[];
}

export interface WireChatResponse {
  session_id: string;
  stage?: PlanStage | null;
  /** Legacy mirror of the text blocks. Today's backend returns only this. */
  reply?: string;
  message?: WireMessage;
  /**
   * Elicitations whose status changed this turn — the one just answered, plus
   * any older rows the new question superseded.
   *
   * Load-bearing, not cosmetic. The answered row lives in an earlier message,
   * so without this the client would have to mark it answered itself, and an
   * answer that produces no follow-up question would leave the last block
   * `pending` and still tappable.
   */
  resolved_elicitations?: WireOptionsBlock[];
}

/** Body of a 409. `elicitation` is the authoritative current state. */
export interface WireElicitationConflictBody {
  code?: string;
  detail?: string;
  elicitation: WireOptionsBlock;
}

/** Backend gap — designed now so the client is written against it. */
export interface WireSessionHistoryResponse {
  session_id: string;
  stage?: PlanStage | null;
  messages: WireMessage[];
}
