import { describe, expect, it, vi } from "vitest";

import {
  isElicitationConflict,
  type ElicitationConflictError,
} from "@/lib/agent/errors";
import { createHttpAgentClient } from "@/lib/agent/http-agent-client";
import { ApiError } from "@/lib/api";
import { config } from "@/lib/config";
import { textBlock } from "@/lib/chat";

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function stubFetch(body: unknown, status = 200) {
  return vi.fn(async (_input: RequestInfo | URL, _init?: RequestInit) =>
    jsonResponse(body, status),
  );
}

function sentBody(fetchImpl: ReturnType<typeof stubFetch>, call = 0) {
  return JSON.parse(
    fetchImpl.mock.calls[call][1]?.body as string,
  ) as Record<string, unknown>;
}

function sentHeaders(fetchImpl: ReturnType<typeof stubFetch>, call = 0) {
  return fetchImpl.mock.calls[call][1]?.headers as Record<string, string>;
}

const sentSessionId = (
  fetchImpl: ReturnType<typeof stubFetch>,
  call = 0,
): string => sentBody(fetchImpl, call).session_id as string;

const cfg = { ...config, apiBaseUrl: "http://mock.test/api/v1" };

const clientFor = (fetchImpl: ReturnType<typeof stubFetch>) =>
  createHttpAgentClient(cfg, {
    fetchImpl: fetchImpl as unknown as typeof fetch,
  });

const turn = (text: string) => ({
  clientMessageId: `c-${text}`,
  content: [textBlock(text)],
});

describe("createHttpAgentClient", () => {
  it("posts the turn to /sessions/chat and maps the legacy reply", async () => {
    const fetchImpl = stubFetch({
      session_id: "s-1",
      reply: "Here is your plan.",
      stage: "basics",
    });

    const reply = await clientFor(fetchImpl).send(turn("plan a campaign"));

    expect(fetchImpl.mock.calls[0][0]).toBe(
      "http://mock.test/api/v1/sessions/chat",
    );
    // `message` is the plain-text projection today's backend reads; `content`
    // is the block list that replaces it. `session_id` is minted by the client,
    // so its value is asserted in its own tests below.
    expect(sentBody(fetchImpl)).toEqual({
      session_id: expect.any(String),
      client_message_id: "c-plan a campaign",
      message: "plan a campaign",
      content: [{ type: "text", text: "plan a campaign" }],
    });
    expect(reply).toEqual({
      content: [textBlock("Here is your plan.")],
      stage: "basics",
      resolvedElicitations: [],
    });
  });

  it("prefers the server's blocks over the legacy reply string", async () => {
    const fetchImpl = stubFetch({
      session_id: "s-1",
      reply: "ignored",
      message: {
        id: "m-1",
        content: [
          { type: "text", text: "Pick one." },
          {
            type: "options",
            id: "e-1",
            prompt: "Which inventory?",
            select: "single",
            options: [
              { id: "o-1", label: "Prime Video", value: "PRIME_VIDEO" },
            ],
            status: "pending",
          },
        ],
      },
    });

    const reply = await clientFor(fetchImpl).send(turn("hi"));

    expect(reply.messageId).toBe("m-1");
    expect(reply.content[0]).toEqual(textBlock("Pick one."));
    // The model-facing `value` must not cross the boundary even when the server
    // sends it — the mapper copies option fields one at a time.
    expect(reply.content[1]).toEqual({
      type: "options",
      id: "e-1",
      prompt: "Which inventory?",
      select: "single",
      options: [
        { id: "o-1", label: "Prime Video", description: null, badge: null },
      ],
      allowCustom: false,
      customPlaceholder: null,
      status: "pending",
      answer: null,
    });
  });

  it("maps an echoed answer block back to the domain", async () => {
    // The server replays a user turn, e.g. when rehydrating a transcript.
    const fetchImpl = stubFetch({
      session_id: "s-1",
      message: {
        content: [
          {
            type: "options_response",
            elicitation_id: "e-1",
            selected_option_ids: ["o-1"],
            custom_text: "and Freevee",
          },
          { type: "options_response", elicitation_id: "e-2" },
        ],
      },
    });

    const reply = await clientFor(fetchImpl).send(turn("hi"));

    expect(reply.content).toEqual([
      {
        type: "options_answer",
        elicitationId: "e-1",
        selectedOptionIds: ["o-1"],
        customText: "and Freevee",
      },
      {
        type: "options_answer",
        elicitationId: "e-2",
        selectedOptionIds: [],
        customText: null,
      },
    ]);
  });

  it("narrows an unrecognised elicitation status to expired", async () => {
    // Fails closed: a dead row must never look answerable.
    const fetchImpl = stubFetch({
      session_id: "s-1",
      message: {
        content: [
          {
            type: "options",
            id: "e-1",
            prompt: "Which inventory?",
            select: "single",
            options: [],
            status: "who-knows",
          },
        ],
      },
    });

    const reply = await clientFor(fetchImpl).send(turn("hi"));

    expect(reply.content[0]).toMatchObject({ status: "expired" });
  });

  it("drops a block type it does not understand", async () => {
    const fetchImpl = stubFetch({
      session_id: "s-1",
      message: {
        content: [{ type: "hologram" }, { type: "text", text: "kept" }],
      },
    });

    const reply = await clientFor(fetchImpl).send(turn("hi"));

    expect(reply.content).toEqual([textBlock("kept")]);
  });

  it("omits the plain-text projection on an answer-only turn", async () => {
    // Option labels must never reach a field that becomes prompt context.
    const fetchImpl = stubFetch({ session_id: "s-1", reply: "ok" });

    await clientFor(fetchImpl).send({
      clientMessageId: "c-1",
      content: [
        {
          type: "options_answer",
          elicitationId: "e-1",
          selectedOptionIds: ["o-1"],
          customText: null,
        },
      ],
    });

    expect(sentBody(fetchImpl)).toEqual({
      session_id: expect.any(String),
      client_message_id: "c-1",
      content: [
        {
          type: "options_response",
          elicitation_id: "e-1",
          selected_option_ids: ["o-1"],
          custom_text: null,
        },
      ],
    });
  });

  it("sends a session id on the first turn and reuses it on the next", async () => {
    const fetchImpl = stubFetch({ session_id: "s-1", reply: "ok", stage: null });

    const client = clientFor(fetchImpl);
    await client.send(turn("first"));
    const second = await client.send(turn("second"));

    // Continuity is server-side, so the id has to be present from the very
    // first turn and survive between turns.
    expect(sentSessionId(fetchImpl)).toBeTruthy();
    expect(sentBody(fetchImpl, 1)).toMatchObject({
      session_id: sentSessionId(fetchImpl),
      message: "second",
    });
    expect(second.stage).toBeNull();
  });

  it("keeps its own session id when the server returns a different one", async () => {
    // TEMP behaviour: the id is minted client-side because the endpoint that
    // issues one isn't live yet, so the server's echo is not adopted.
    const fetchImpl = stubFetch({ session_id: "s-1", reply: "ok" });

    const client = clientFor(fetchImpl);
    await client.send(turn("first"));
    await client.send(turn("second"));

    expect(sentSessionId(fetchImpl, 1)).not.toBe("s-1");
    expect(sentSessionId(fetchImpl, 1)).toBe(sentSessionId(fetchImpl));
  });

  it("mints a distinct session id per client, so a new chat is a new session", async () => {
    const fetchImpl = stubFetch({ session_id: "s-1", reply: "ok" });

    await clientFor(fetchImpl).send(turn("first"));
    await clientFor(fetchImpl).send(turn("second"));

    expect(sentSessionId(fetchImpl, 1)).not.toBe(sentSessionId(fetchImpl));
  });

  it("sends the advertiser header the backend requires", async () => {
    const fetchImpl = stubFetch({ session_id: "s-1", reply: "ok" });

    await clientFor(fetchImpl).send(turn("hi"));

    expect(sentHeaders(fetchImpl)).toMatchObject({
      "Vowmade-Advertiser-Id": expect.any(String),
    });
  });

  it("surfaces a failed request as an error carrying the server detail", async () => {
    const fetchImpl = stubFetch({ detail: "Rate limit exceeded" }, 429);

    await expect(clientFor(fetchImpl).send(turn("hi"))).rejects.toThrowError(
      "Rate limit exceeded",
    );
  });

  it("maps a 409 to a typed conflict carrying the server's state", async () => {
    const fetchImpl = stubFetch(
      {
        code: "elicitation_conflict",
        detail: "Already answered.",
        elicitation: {
          type: "options",
          id: "e-1",
          prompt: "Which inventory?",
          select: "single",
          options: [{ id: "o-1", label: "Prime Video" }],
          status: "answered",
          answer: {
            selected_option_ids: ["o-1"],
            custom_text: null,
            answered_at: "2026-08-10T09:30:00.000Z",
          },
        },
      },
      409,
    );

    const failure = await clientFor(fetchImpl)
      .send(turn("hi"))
      .catch((cause: unknown) => cause);

    expect(isElicitationConflict(failure)).toBe(true);
    const conflict = failure as ElicitationConflictError;
    expect(conflict.elicitation.status).toBe("answered");
    expect(conflict.elicitation.answer).toEqual({
      selectedOptionIds: ["o-1"],
      customText: null,
      answeredAt: Date.parse("2026-08-10T09:30:00.000Z"),
    });
  });

  it("leaves a 409 with no elicitation body as a plain ApiError", async () => {
    // Unrecognizable: there is no authoritative state to reconcile against.
    const fetchImpl = stubFetch({ detail: "Conflict" }, 409);

    const failure = await clientFor(fetchImpl)
      .send(turn("hi"))
      .catch((cause: unknown) => cause);

    expect(isElicitationConflict(failure)).toBe(false);
    expect(failure).toBeInstanceOf(ApiError);
  });

  it("nulls an unparseable answered_at rather than passing NaN on", async () => {
    const fetchImpl = stubFetch({
      session_id: "s-1",
      message: {
        content: [
          {
            type: "options",
            id: "e-1",
            prompt: "Which inventory?",
            select: "multi",
            options: [],
            status: "answered",
            answer: { selected_option_ids: [], answered_at: "not a date" },
          },
        ],
      },
    });

    const reply = await clientFor(fetchImpl).send(turn("hi"));

    expect(reply.content[0]).toMatchObject({
      select: "multi",
      answer: { answeredAt: null, selectedOptionIds: [] },
    });
  });
});
