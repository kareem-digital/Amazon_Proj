import { createHttpAgentClient } from "@/lib/agent/http-agent-client";
import type { AgentClient } from "@/lib/agent/types";
import { config as defaultConfig, type AppConfig } from "@/lib/config";

/**
 * Resolves the agent transport from configuration.
 *
 * Deliberately a factory rather than a module-level singleton: a singleton
 * would bake the choice in at import time, which is what made the previous
 * app's transport impossible to swap, stub or inject from a host.
 */
export function createAgentClient(cfg: AppConfig = defaultConfig): AgentClient {
  return createHttpAgentClient(cfg);
}
