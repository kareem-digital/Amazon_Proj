import { describe, expect, it } from "vitest";

import {
  ElicitationConflictError,
  isElicitationConflict,
} from "@/lib/agent/errors";
import { makeOptionsBlock } from "@/test/factories";

describe("ElicitationConflictError", () => {
  it("carries the server's authoritative state and names the status", () => {
    const elicitation = makeOptionsBlock({ id: "e-1", status: "superseded" });
    const cause = new Error("409");

    const error = new ElicitationConflictError(elicitation, {
      requestId: "req-1",
      cause,
    });

    expect(error.elicitation).toBe(elicitation);
    expect(error.name).toBe("ElicitationConflictError");
    expect(error.message).toBe("Elicitation e-1 is superseded.");
    expect(error.requestId).toBe("req-1");
    expect(error.cause).toBe(cause);
  });

  it("is usable without the optional request context", () => {
    const error = new ElicitationConflictError(makeOptionsBlock());

    expect(error.requestId).toBeUndefined();
    expect(error).toBeInstanceOf(Error);
  });
});

describe("isElicitationConflict", () => {
  it("narrows a conflict and rejects anything else", () => {
    expect(
      isElicitationConflict(
        new ElicitationConflictError(makeOptionsBlock()),
      ),
    ).toBe(true);
    expect(isElicitationConflict(new Error("boom"))).toBe(false);
    expect(isElicitationConflict(null)).toBe(false);
  });
});
