export {
  AgentClientProvider,
  useAgentClient,
} from "@/lib/agent/agent-client-context";
export type { AgentClientProviderProps } from "@/lib/agent/agent-client-context";
export { createAgentClient } from "@/lib/agent/create-agent-client";
export {
  ElicitationConflictError,
  isElicitationConflict,
} from "@/lib/agent/errors";
export { createHttpAgentClient } from "@/lib/agent/http-agent-client";
export type {
  AgentClient,
  AgentHistory,
  AgentReply,
  AgentRequest,
  PlanStage,
  SendOptions,
} from "@/lib/agent/types";
