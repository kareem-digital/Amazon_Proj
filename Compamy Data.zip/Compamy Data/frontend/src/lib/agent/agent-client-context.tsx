/* eslint-disable react-refresh/only-export-components --
   The provider and its hook are one unit; splitting them across files buys
   nothing but an extra import. */
import { createContext, useContext, useMemo, type ReactNode } from "react";

import { createAgentClient } from "@/lib/agent/create-agent-client";
import type { AgentClient } from "@/lib/agent/types";
import { config as defaultConfig } from "@/lib/config";

const AgentClientContext = createContext<AgentClient | null>(null);

export interface AgentClientProviderProps {
  children: ReactNode;
  /**
   * Supply a client directly. Tests pass a stub this way; a host embedding the
   * widget can pass its own implementation.
   */
  client?: AgentClient;
  /** Config overrides used when no `client` is given. */
  apiBaseUrl?: string;
}

/**
 * Owns transport resolution for everything beneath it. Construction is lazy
 * and memoized, so selecting the HTTP client never runs at module-import time.
 */
export function AgentClientProvider({
  children,
  client,
  apiBaseUrl,
}: AgentClientProviderProps) {
  const value = useMemo(
    () =>
      client ??
      createAgentClient({
        ...defaultConfig,
        ...(apiBaseUrl !== undefined && { apiBaseUrl }),
      }),
    [client, apiBaseUrl],
  );

  return (
    <AgentClientContext.Provider value={value}>
      {children}
    </AgentClientContext.Provider>
  );
}

/** The only way the UI reaches the backend. */
export function useAgentClient(): AgentClient {
  const client = useContext(AgentClientContext);
  if (!client) {
    throw new Error(
      "useAgentClient must be used inside an <AgentClientProvider>.",
    );
  }
  return client;
}
