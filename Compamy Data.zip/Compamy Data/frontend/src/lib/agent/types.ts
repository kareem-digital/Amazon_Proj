import type {
  ChatMessage,
  MessageBlock,
  OptionsBlock,
  UserBlock,
} from "@/types/chat";

/** How far the agent has taken the plan. Null until it reaches a stage. */
export type PlanStage = "basics" | "inventory" | "audiences" | "forecast";

/**
 * One user turn: typed text, or a recorded elicitation answer, or both.
 *
 * There is deliberately no `history` field. The backend keeps conversation
 * state server-side keyed by the session id, and serializing local elicitation
 * state back to the server that owns it is exactly the bug this design exists
 * to prevent.
 */
export interface AgentRequest {
  /** Idempotency key, owned by the caller so a retry reuses it. */
  clientMessageId: string;
  content: UserBlock[];
}

export interface AgentReply {
  /** Server message id when supplied; the caller falls back to its own. */
  messageId?: string;
  content: MessageBlock[];
  stage?: PlanStage | null;
  /**
   * Elicitations whose server-owned status changed this turn. The caller patches
   * them into the transcript, which is how a question in an earlier message
   * stops being open without the client ever deciding that for itself.
   */
  resolvedElicitations?: OptionsBlock[];
}

export interface AgentHistory {
  messages: ChatMessage[];
  stage?: PlanStage | null;
}

export interface SendOptions {
  signal?: AbortSignal;
}

/**
 * Transport boundary for agent responses. The UI only ever talks to this
 * interface, so the mock can be swapped for the FastAPI client without
 * touching a component, a hook or a test.
 */
export interface AgentClient {
  send(request: AgentRequest, options?: SendOptions): Promise<AgentReply>;
  /**
   * Rehydrates a conversation, including each elicitation's server-owned
   * status. Optional until the backend exposes session history — see the
   * backend gaps in `docs/elicitation.md`.
   */
  loadHistory?(options?: SendOptions): Promise<AgentHistory>;
}
