import type { OptionsBlock } from "@/types/chat";

/**
 * The server refused an answer because the elicitation is no longer pending.
 *
 * Carries the authoritative current state so a stale tab corrects itself
 * instead of silently double-answering. Raised by the transport, which is the
 * only layer that knows a 409 body when it sees one.
 */
export class ElicitationConflictError extends Error {
  /** Server state, already mapped to domain. */
  readonly elicitation: OptionsBlock;
  readonly requestId?: string;

  constructor(
    elicitation: OptionsBlock,
    options: { requestId?: string; cause?: unknown } = {},
  ) {
    super(`Elicitation ${elicitation.id} is ${elicitation.status}.`, {
      cause: options.cause,
    });
    this.name = "ElicitationConflictError";
    this.elicitation = elicitation;
    this.requestId = options.requestId;
  }
}

export function isElicitationConflict(
  cause: unknown,
): cause is ElicitationConflictError {
  return cause instanceof ElicitationConflictError;
}
