# Agentic VOW

Conversational planning agent for CTV campaigns on Amazon DSP.

A trader describes what they want; the agent builds a **Strategy** by calling
VOW's existing platform APIs, and a human approves the plan before anything
is committed. VOW's platform remains the execution engine to Amazon.

## Repository layout

```vow-agent/
├── backend/     FastAPI + LangGraph agent service
├── frontend/    React embeddable widget (Vite + Tailwind + daisyUI)
└── docker-compose.yml   runs everything locally
```

## Quick start

**Full stack (recommended):**

```bash
# Build all service images
docker compose build

# Start the complete local stack
docker compose up

# Stop and remove the local stack
docker compose down
```

| Service  | URL                                          |
|----------|----------------------------------------------|
| Backend  | http://localhost:8000/docs                    |
| Frontend | http://localhost:3000/agent/                  |
| MFE      | http://localhost:3000/mfe/remoteEntry.js      |
| Postgres | localhost:5432 (vowagent/vowagent)            |
| Redis    | localhost:6379                                |

After starting the stack, verify that its HTTP endpoints return successfully:

```bash
curl --fail http://localhost:8000/api/v1/health/ready
curl --fail --head http://localhost:3000/agent/
curl --fail --head http://localhost:3000/mfe/remoteEntry.js
```

## Staging deployment

A push to `staging` builds ARM64 frontend and backend images, tags them with the
Git commit SHA, pushes them to the development ECR registry, and deploys them to
the `vowagent` namespace in the `vowmade-dev` EKS cluster.

| Component | Location |
|-----------|----------|
| Frontend image | `vowagent-dev-frontend:<commit-sha>` |
| Backend image | `vowagent-dev-backend:<commit-sha>` |
| Application | https://staging.vowmade.dev/agent/ |
| Backend health | https://staging.vowmade.dev/agent-api/v1/health/ready |
| MFE entry | https://staging.vowmade.dev/mfe/remoteEntry.js |

The workflow authenticates to AWS with GitHub OIDC and deploys the exact images
produced by the same workflow run. A failed Helm upgrade rolls back
automatically. Staging and pull request previews use the existing shared Vowmade
staging ALB. Environment-specific Helm variables are stored under `helm/envs/`.

### Pull request previews

Each same-repository pull request into `staging` receives an isolated preview at:

```text
https://bbd-agent-pr-<pr-number>.vowmade.dev/agent/
```

The corresponding MFE and backend endpoints are:

```text
https://bbd-agent-pr-<pr-number>.vowmade.dev/mfe/remoteEntry.js
https://bbd-agent-pr-<pr-number>.vowmade.dev/agent-api/v1/
```

The preview builds both images from the PR head SHA, tags them as
`bbd-pr-<pr-number>-<sha>`, and deploys that exact tag to the `vowagent`
namespace. It uses in-memory state and the mock MCP integration, with no external
service credentials. Fork pull requests never receive AWS access. Closing the PR
removes its Helm release, services, ingress rules, DNS record, and both BBD image
tags automatically. The cleanup workflow can also be run manually with a PR
number.

**Backend only:**

```bash
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements-dev.txt
copy ..\.env.example .env
uvicorn app.main:app --reload
```

**Frontend only:**

```bash
cd frontend
npm i
copy .env.example .env
npm run dev:remote
```

## Running tests & reports

**Backend** (requires Python 3.11+ — the app uses `datetime.UTC`):

```bash
cd backend
pytest
```

A single `pytest` run generates four reports in `backend/reports/`: `backend-Pylint_report.txt` (lint), `backend-Pytest_coverage.xml` (coverage), `backend-Pytest_report.xml` (JUnit), `backend-Pytest_report.html` (self-contained — safe to open directly in a browser).

**Frontend:**

```bash
cd frontend
npm run test:coverage
```

A single command generates four reports in `frontend/reports/`: `frontend-ESLint_report.txt` (lint), `frontend-Vitest_coverage.xml` (coverage), `frontend-Vitest_report.xml` (JUnit), `frontend-Vitest_report.html` (test results). Unlike the backend's HTML report, this one isn't self-contained — don't open it via `file://`; run `npm run report:open` instead to view it in a browser.

Both `ci-backend.yml` and `ci-frontend.yml` upload their `reports/` folder as a downloadable CI artifact on every pipeline run.

## Operations

### Emergency stop

The **presence** of a file halts every call the agent makes to VOW. Presence
rather than contents, so it cannot be ambiguously half-enabled.

```bash
cd backend
touch KILL_SWITCH     # agent halted
rm KILL_SWITCH        # agent resumes
```

Takes effect on the **next call** — no restart, no redeploy. While engaged, the
API answers `503 The agent is temporarily halted.` and every blocked call is
recorded in the audit trail, so the incident window is evidenced rather than
blank.

Engaging and releasing it both log at `CRITICAL` (`killswitch.engaged` /
`killswitch.released`); blocked calls log at `WARNING`.

> Currently a file, which means it needs shell access to the box and works for
> one server only. See `TMP-19` in
> [docs/PROVISIONAL_DECISIONS.md](docs/PROVISIONAL_DECISIONS.md).

### Governance policy

What the agent is and is not allowed to do lives in one file:
`backend/app/governance/policies/vow_ctv.yaml`. Every VOW call is checked
against it before leaving the process; a refusal returns `403` and never
reaches VOW.

**Two rules if you edit it**, both verified against AGT 4.1.0 and both failing
*silently* if ignored:

1. **Never use `not in`.** It does not raise — it never matches, so a rule
   built on it permits everything it was written to forbid.
2. **Write allow-lists, not deny-lists.** With `default_action: deny`, a
   missing field then fails closed rather than slipping through.

Tests in `backend/tests/unit/governance/` enforce both.

### Audit trail

The durable, signed record of every allow/deny decision — separate from logs,
which expire. Set `AUDIT_LOG_PATH` and `AUDIT_HMAC_KEY` to persist it; leave
them empty and it is held in memory and lost on restart (the service warns at
startup).

```bash
cat backend/logs/audit.jsonl | jq '{action, outcome, agent_did}'
```

Client budgets are **not** stored — only a hash, so a dispute can be settled
without retaining commercial data.

## Configuration

Every setting has a local-friendly default, so a fresh clone runs with no
`.env` at all: mock VOW data, in-memory state, no LLM, no secrets. See
[.env.example](.env.example) for the full list and what each one does.

The ones worth knowing:

| Variable | Default | Effect |
|---|---|---|
| `OPENAI_API_KEY` | empty | Empty = pattern matching instead of an LLM |
| `USE_MOCK_MCP` | `true` | Canned VOW data; the real server does not exist yet |
| `KILL_SWITCH_PATH` | `KILL_SWITCH` | Emergency stop, above |
| `AUDIT_LOG_PATH` | empty | Empty = audit records are lost on restart |
| `LOG_LEVEL` | `INFO` | `DEBUG` includes raw briefs and full payloads |
| `CORS_ORIGINS` | `:3000` | **Must be JSON** — a bare URL will not parse |

## Documentation

In this repo:

- [docs/AGENT_API_FOR_UI.md](docs/AGENT_API_FOR_UI.md) — the endpoints the
  frontend consumes, verified against a running app
- [docs/PROVISIONAL_DECISIONS.md](docs/PROVISIONAL_DECISIONS.md) — what is
  deliberately temporary and what must change before it is not acceptable
- `backend/docs/VOW_Strategy_Schema_v2.md` — the cross-lane Strategy contract

Architecture decisions, the domain glossary, the API integration reference and
the lane working documents live in Confluence.

## Conventions

Branch, commit and PR naming:

| | Format | Example |
|---|---|---|
| Branch | `JIRA-ID/jira-story-title` | `VA-297/agent-starter-code` |
| Commit | `[JIRA-ID][feature\|bugfix] Story title` | `[VA-297][feature] Agent starter code` |
| PR title | `[JIRA-ID] Story title` | `[VA-297] Agent starter code` |

- **Branch from `staging`, and raise PRs into `staging`** — not `main`. `main`
  is a release line and has drifted behind. Branching from it produces
  conflicts.
- Every PR links its Jira ticket
- CI must be green before merge
- No secrets in code
